#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
from __future__ import (unicode_literals, division, absolute_import, print_function)

__license__ = 'GPL v3'
__copyright__ = '2012-2025, John Howell <jhowell@acm.org>'


# Important release notes that need to be shown to the user after install of new version

# list of release notes as tuples of release version and html text, newest first

RELEASE_NOTES = [
    ]

LAST_RELEASE_NOTE_VERSION = None
